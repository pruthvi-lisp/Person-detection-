# Human body > 2024-03-16 12:07pm
https://universe.roboflow.com/annotate-images-vgizw/human-body-0d0l1

Provided by a Roboflow user
License: CC BY 4.0

